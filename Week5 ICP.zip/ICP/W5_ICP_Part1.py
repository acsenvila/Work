
#   Author - Alex Acsenvil
#   Class - 5590-001 - Python and Deep Learning Programming for Engineers and Scientists
#   Week 5 In Class Programming Part 1
#   My brain is spinning every Friday as I learn so much...ICP does not do justice to the amount of information I am leaning, but the concepts learned
#   are applicable in many diverse areas outside of class.  Kudos to TAs and Instructors :)

# In this week's assignment we are to create a linear regression model for the dataset below (link) using NumPy. Plot the model using matplotlib.
# Link is https://umkc.box.com/s/dtqud5vqttj2zsk6yd618yjds9zvxq6c
#In the dataset data pairs     X = national unemployment rate for adult males     Y = national unemployment rate for adult females
#   X = 2.900000095, 6.699999809, 4.900000095, 7.900000095, 9.800000191, 6.900000095, 6.099999905, 6.199999809, 6, 5.099999905, 4.699999809, 4.400000095, 5.800000191
#   Y = 4, 7.400000095, 5, 7.199999809, 7.900000095, 6.099999905, 6, 5.800000191, 5.199999809, 4.199999809, 4, 4.400000095, 5.199999809



import csv
import numpy as np
from sklearn import linear_model
import matplotlib.pyplot as plt

# X and Y variable data (xd or yd)
xd = []
yd = []# function getting the data from the csv file below -

# function getting the data from the csv file below -

def get_data(filename):
    with open(filename, 'r') as csvfile:
        csvFileReader = csv.reader(csvfile)
        next(csvFileReader)  # skipping column names
        for row in csvFileReader:
            xd.append(float(row[0]))
            yd.append(float(row[1]))
    return
# function plotting the x and y data from the csv file below -

def show_plot(xd, yd):
    linear_mod = linear_model.LinearRegression()
    xd = np.reshape(xd, (len(xd), 1))  # converting to matrix of n X 1
    yd = np.reshape(yd, (len(yd), 1))
# modeling data fit
    linear_mod.fit(xd, yd)
    plt.scatter(xd, yd, color='red')  # plotting the initial datapoints
    plt.plot(xd, linear_mod.predict(xd), color='black', linewidth=5)  # plotting the line made by linear regression
    plt.show()
    return
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#   Remnant code from google stock price predict.  I will be using this code for my own research to expand this
#   with data collection

def predict_price(xd, yd, x):
    linear_mod = linear_model.LinearRegression()  # defining the linear regression model
    xd = np.reshape(xd, (len(xd), 1))  # converting to matrix of n X 1
    yd = np.reshape(yd, (len(yd), 1))
    linear_mod.fit(xd, yd)  # fitting the data points in the model
    predicted_yd = linear_mod.predict(x)
    return predicted_yd[0][0], linear_mod.coef_[0][0], linear_mod.intercept_[0]
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#   Function call to get data from csv
get_data('slr04.csv')
#   Printing X column
print("x variable data: \n", xd)

#print("\n")
#   Printing Y column
print("y variable data: \n",yd)

#   Generating the image plot via matplotlib library call for x and y datapoints
show_plot(xd,yd)

