# Q2. remove everything in the file 1 that is inside file 2

filename1 = 'testfile1.txt'             # file 1
filename2 = 'testfile2.txt'             # file 2
infile1=open(filename1)                 # open file 1
infile2=open(filename2)                 # open file 2
line1=infile1.readline()                # read line from file 1
line2=infile2.readline()                # read line from file 2
listline1=line1.split(" ")              # return a list of string from file 1 separated by space
listline2=line2.split(" ")              # return a list of string from file 2 separated by space
sepa=" "
difstr=[]

print("the file 1 is: ",line1)
print("the file 2 is: ",line2)
for i in listline1:
    if (i and i.lower()) not in listline2:      # ignore the capitalization and filter out the strings in list 2
        difstr.append(i)
# join the elements of sequence using separator " " and print it out
print("the result after removing file 2 from file is: \n",sepa.join(difstr))

