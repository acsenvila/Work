#   In class programming:
# 1 . Implementing Naïve Bayes method using scikit-learn library
# Use iris dataset available in https://umkc.box.com/s/l3di4n6no384oi6k30hmdcbq7y7e2jbl
# Use cross validation to create training and testing part
# Evaluate the model on testing part

#   Load the Gaussian Naive Bayes model to evaluate the training and set components of the model
from sklearn import datasets
from sklearn import metrics
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split

#   loading the iris datasets included in the library

dataset = datasets.load_iris()
x_train, x_test, y_train, y_test = train_test_split(dataset.data, dataset.target, stratify = dataset.target, random_state = 42)
# fit a Naive Bayes model to the data
model = GaussianNB()
model.fit(x_train, y_train)
# evaluating GNB classifier

print ("accuracy on training dataset: %r" % model.score(x_train, y_train))
print ("accuracy on testing dataset: %r" % model.score(x_test, y_test))


# Bernoulli Naive Bayes
from sklearn import datasets
from sklearn import metrics
from sklearn.naive_bayes import BernoulliNB
from sklearn.model_selection import train_test_split

#   loading the iris datasets included in the library
dataset = datasets.load_iris()
x_train, x_test, y_train, y_test = train_test_split(dataset.data, dataset.target)
# fit a Naive Bayes model to the data
model = BernoulliNB()
model.fit(x_train, y_train)
# evaluating BNB classifier

print ("accuracy on training dataset: %r" % model.score(x_train, y_train))
print ("accuracy on testing dataset: %r" % model.score(x_test, y_test))


# Multinomial Naive Bayes
from sklearn import datasets
from sklearn import metrics
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split

#   loading the iris datasets included in the library
dataset = datasets.load_iris()
x_train, x_test, y_train, y_test = train_test_split(dataset.data, dataset.target)
# fit a Naive Bayes model to the data
model = MultinomialNB()
model.fit(x_train, y_train)

# evaluating MNB classifier

print ("accuracy on training dataset: %r" % model.score(x_train, y_train))
print ("accuracy on testing dataset: %r" % model.score(x_test, y_test))

