#   Author - Alex Acsenvil
#   Class - 5590-001 - Python and Deep Learning Programming for Engineers and Scientists
#   Week 5 In Class Programming Part 2
#   The sample dataset below is 6 objects with two variable(X,Y). your task is to cluster this dataset into Two cluster (k=2)
#   subject=1,2,3,4,5,6
#   x=1.0,1.5,3.0,5.0,3.5,4.5
#   y=1.0,2.0,4.0,7.0,5.0,5.0

#U  sing the imported numpy, matplotlib, and scikit-learn library.

from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt

#V  alues from the given table - Next step is to read from a file
xd=[1.0,1.5,3.0,5.0,3.5,4.5]
yd=[1.0,2.0,4.0,7.0,5.0,5.0]
X=np.column_stack((xd,yd))

# Printing the training values of X and Y.
print(X)

kmeans = KMeans(n_clusters=2,max_iter=100, random_state=0).fit(X)

print(kmeans.labels_)

print(kmeans.cluster_centers_)

# Clustering the data into two different colors, black, and orange.

plt.scatter(xd[0:2],yd[0:2],color='black',label='ClusterUno')

plt.scatter(xd[2:],yd[2:],color='orange',label='ClusterDo')
#   Print/Show the legend representing the clusters, in Spanish, and Hindi.
plt.legend()
#   Display the Clusters' plots.
plt.show()

