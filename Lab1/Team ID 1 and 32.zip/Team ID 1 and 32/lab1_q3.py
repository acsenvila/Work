# Q3. Find the list of students who are attending “python” classes but not “Web Application”

# list of student in "python class"
Plist=['Anna','Adam','Ben','Chloe','Dan','Ella','Fin','Greg','Henry','Ian','Jake','Micheal','Monica','Nancy','Peter','Steve','Ted','Zach']
# list of student in "Web Application" class
WAlist=['Adam','Ben','Blake','Dan','Ella','Fin','Greg','Ian','Jake','Luke','Micheal','Monica','Paul','Peter','Steve','Zoe']
print("student in python class: \n",Plist)
print("student in Web Application class: \n",WAlist)
inPnotWAlist=[]
for i in Plist:
    if i not in WAlist:
        inPnotWAlist.append(i)
print('the list of students who are attending python not web application are: \n',inPnotWAlist)