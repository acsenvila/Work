#   2. Implement linear SVM method using scikit library
# Use the same iris csv from Part 1 of Week 6 ICP
# Which algorithm you got better accuracy? Can you justify why?
#   3. use the SVM with RBF kernel on the same dataset. How the result changed?

# importing packages
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris

# #loading iris dataset to variable
iris = load_iris()

# spliting the data into training and testing
x_train, x_test, y_train, y_test = train_test_split(iris.data, iris.target, random_state=0)
# using linear kernel for svm
svm = SVC(kernel='linear')
# fitting the data using SVM
svm.fit(x_train, y_train)
# evaluating SVM using linear to the training and test data from memory
print ("the accuracy on training subset with linear SVM is: %r" % svm.score(x_train, y_train))
print ("the accuracy on test subset with linear SVM is: %r" % svm.score(x_test, y_test))

# 3. use the SVM with RBF kernel on the same dataset. How the result changed?
# On this data set, not much has changed in terms of the results for accuracy.
# They are very much identical as if to say the data and learning algorithm in both SVM and RBF Kernel represents
# a holistic picture and accuracy to predicting data sets organized as such in the iris csv file.

# spliting dataset for RBF kernel
x_train, x_test, y_train, y_test = train_test_split(iris.data, iris.target, random_state=0)
# applying RBF kernel
svm = SVC(kernel='rbf')
# applying SVM RBF Kernel to the training and test data from memory
svm.fit(x_train, y_train)
# Evaluating SVM using RBF
print ("the accuracy on training subset with RBF Kernel is: %r" % svm.score(x_train, y_train))
print ("the accuracy on test subset with RBF Kernel is: %r" % svm.score(x_test, y_test))