"""Q6. program a code which download a webpage contains a table using Request library, then parse the page using Beautifusoup library.
# You should save all the information of the table in a file. Sample input: https://www.fantasypros.com/nfl/reports/leaders/qb.php?year=2015
# Sample output: Save the table in this link into a file
"""
from bs4 import BeautifulSoup
from urllib.request import urlopen
import ssl

url = "https://www.fantasypros.com/nfl/reports/leaders/qb.php?year=2015"    # url that is scraped
# create a custom ssl context in the context parameter in case urllib will raise an exception when it can't verify the server certificate
context = ssl._create_unverified_context()
html = urlopen(url,context=context)     # the html from given url
# create an BeautifulSoup object by passing through html to the BeautifulSoup constructor
soup = BeautifulSoup(html, "html.parser")
# returns a list of BeautifulSoup Tag div objects that has the class: mobile-table
result_list = soup.findAll('div', {'class': "mobile-table"})
file = open('table_content.txt','w')       # open the file to write output
data=[]
header=[]

for div in result_list:
    result_table = div.find('table')
# to extract the column header from the table
    result_header = div.find('thead')
    table_header = result_header.findAll('th')
    for th in table_header:
        column_header = th.getText()
        header.append(column_header)
# to extract the cell element from the table for each row
    table_body = result_table.find('tbody')
    rows = table_body.find_all('tr')
    for row in rows:
        columns = row.findAll('td')
        item = [col.getText() for col in columns]
        data.append(item)

file.write(str(header))         # write the table header into the file
file.write("\n")
print(str(header))
for i in data:
    file.write(str(i))          # write the table content into the file'
    file.write("\n")
    print(str(i))

file.close()
